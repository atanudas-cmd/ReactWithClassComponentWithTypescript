import React from 'react';
import './App.css';
import ListComponent from './Components/Lists/ListComponent';
import ConditionComponent from './Components/Conditions/ConditionComponent';
import RenderingData from './Components/RenderingListOfData/RenderingData';
import StatefullList from './Components/StatefullList/StatefullList';
import Keys from './Components/UnderStandingKeys/Keys';
import ConditionalContents from './Components/ConditionalContents/ConditionalContents';
import ConditionalReturnStatement from './Components/ConditionalReturnStatement/ConditionalReturnStatement';
import BasicComponent from './Components/ReactComponents/BasicComponent';
import ParentComponent from './Components/NestingComponents/ParentComponent';
import GreetingsParent from './Components/Props/GreetingsParent';
import DynamicUserInterface from './Components/ComponentStatesDynamicUserInterface/DynamicUserInterface';
import DefaultProps from './Components/Props/DefaultProps';
import PropsUsingSpreadOperatorParent from './Components/Props/PropsUsingSpreadOperatorParent';
import Parent from './Components/ComponentComposition/Parent';



function App() {
  return (
    <div>
      {/* <ListComponent/> */}
      {/* <ConditionComponent/> */}
      {/* <RenderingData/> */}
      {/* <StatefullList/> */}
      {/* <Keys/> */}
      {/* <ConditionalContents/> */}
      {/* <ConditionalReturnStatement/> */}
      {/* <BasicComponent/> */}
      {/* <ParentComponent/> */}
      {/* <GreetingsParent/> */}
      {/* <DynamicUserInterface/> */}
      {/* <DefaultProps/> */}
{/* <PropsUsingSpreadOperatorParent/> */}
<Parent/>
    </div>
  );
}

export default App;
