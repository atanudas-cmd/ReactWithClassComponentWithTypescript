import React, { Component } from 'react';

interface Istate {
    isLoggedIn: boolean,
};

export default class ConditionComponent extends Component<any, Istate> {
    render() {
        // const isLoggedIn = true;
        const isLoggedIn = false;
        return (
            <div>
                <h2>Welcome to the App!</h2>
                {
                    isLoggedIn ? (<p>You are loggedIn</p>) : (<p>Please log in to the App</p>)
                }
            </div>
        )
    }
}
