import React, { Component } from 'react'

interface Item {
    id: number,
    name: string,
};

export default class RenderingData extends Component {
    render() {

        const data: Item[] = [
            { id: 1, name: 'Atanu' },
            { id: 2, name: 'Ram' },
            { id: 3, name: 'Shyam' },
        ];

        return (
            <div>
                <h2>List of Items</h2>
                <ul>
                    {data.map((item: Item) => (
                        <li key={item.id}>{item.name}</li>
                    ))}
                </ul>
            </div>
        )
    }
}
