import React, { Component } from 'react'
import Card from './Card';
import Button from './Button';
interface ParentProps {
    name: string;
}
export default class Parent extends Component<any, ParentProps>{
    render() {
        const { name } = this.props;
        return (
            <div>
                <h1>Hello, {name}</h1>
                <Card title="Card Title"  />
                <Button onClick={() => console.log('Button clicked')} text="Click Me" />
            </div>
        )
    }
}
