import React, { Component } from 'react';

interface ButtonProps {
    onClick: () => void;
    text: string;
}

export default class Button extends Component<any, ButtonProps> {
    render() {
        const { onClick, text } = this.props;

        return (
            <button onClick={onClick}>{text}</button>
        );
    }
}
