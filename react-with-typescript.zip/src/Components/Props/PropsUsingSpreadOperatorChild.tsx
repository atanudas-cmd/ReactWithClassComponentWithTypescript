import React, { Component } from 'react'
interface ChildComponentProps {
    prop1: string;
    prop2: number;
}
export default class PropsUsingSpreadOperatorChild extends Component<any,ChildComponentProps> {
    render() {
        const { prop1, prop2 } = this.props;
        return (
            <div>
                <p>prop1: {prop1}</p>
                <p>prop2: {prop2}</p>
            </div>
        )
    }
}
