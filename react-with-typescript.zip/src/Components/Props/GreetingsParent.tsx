import React, { Component } from 'react'
import GreetingsChild from './GreetingsChild'

export default class GreetingsParent extends Component{
  render() {
    return (
      <div>
       <GreetingsChild name ="Atanu Das" age = "23" />
      </div>
    )
  }
}
