import React, { Component } from 'react'
interface IProps {
    namre: string,
    age: number
}
export default class GreetingsChild extends Component<any, IProps> {
    render() {
        return (
            <div>
                <h3>
                    My name is : {this.props.name},
                    & This is my age  : {this.props.age}
                </h3>
                {/* <h1>This is my age  : {this.props.age}</h1> */}
            </div>
        )
    }
}
