import React, { Component } from 'react'
interface GreetingProps {
    name: string;
}

interface GreetingState {
    message: string;
}
export default class DefaultProps extends Component<GreetingProps, GreetingState> {

    static defaultProps = {
        name: 'Atanu'
    };

    constructor(props: GreetingProps) {
        super(props);
        this.state = {
            message: `Hello, ${props.name}!`
        };
    }

    render() {
        const { message } = this.state;
        return (
            <div>
             <h1>{message}</h1>;
            </div>
       
        )
    }
}
