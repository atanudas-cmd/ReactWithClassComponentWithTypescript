import React, { Component } from 'react'
import PropsUsingSpreadOperatorChild from './PropsUsingSpreadOperatorChild';

interface MyComponentProps {
  prop1: string;
  prop2: number;
}


export default class PropsUsingSpreadOperatorParent extends Component<any,MyComponentProps>{
  render() {
    const { prop1, prop2 } = this.props;


    return (
      <div>
        <PropsUsingSpreadOperatorChild {...this.props}  />
      </div>
    )
  }
}
