import React, { Component } from 'react'

export default class ChildComponent extends Component {
  render() {
    return (
      <div>
        <h3>Child Component.</h3>
        <p>This is child component Content.</p>
        <p>This message show using parentComponent.</p>
      </div>
    )
  }
}
