import React, { Component } from 'react'
import ChildComponent from './ChildComponent'

export default class ParentComponent extends Component {
  render() {
    return (
      <div>
        <ChildComponent />
      </div>
    )
  }
}
