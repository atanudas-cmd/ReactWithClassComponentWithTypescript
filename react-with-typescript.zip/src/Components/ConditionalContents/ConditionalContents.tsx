import React, { Component } from 'react';

interface Istate {
    isLoggedIn: boolean,
};

export default class ConditionalContents extends Component<any, Istate> {
    render() {
        // const isLoggedIn = true;
        const isLoggedIn = false;
        if (isLoggedIn) {
            return (
                <div>
                    <h1>Welcome to the App!</h1>
                    <p>You are logged in.</p>
                </div>
            );
        } else {
            return (
                <div>
                    <h1>Welcome to the App!</h1>
                    <p>Please log in to continue.</p>
                </div>
            )
        }

    }
}


/*
In React class components, you can render conditional content by using JavaScript's conditional statements, 
such as `if` statements or ternary operators, within the `render` method. This allows you to selectively 
render different components or content based on certain conditions.


render() {
  const isLoggedIn = true;

  return (
    <div>
      <h1>Welcome to the App!</h1>
      {isLoggedIn ? <p>You are logged in.</p> : <p>Please log in to continue.</p>}
    </div>
  );
}
*/