import React, { Component } from 'react'
interface Istate {
    isLoggedIn:boolean
}
export default class ConditionalReturnStatement extends Component<any,Istate> {
    render() {
        const isLoggedIn = false;

        if (isLoggedIn) {
            return (
                <div>
                    <h1>Welcome to the App!</h1>
                    <p>You are logged in.</p>
                </div>
            );
        } else {
            return (
                <div>
                    <h1>Welcome to the App!</h1>
                    <p>Please log in to continue.</p>
                </div>
            );
        }
    }
}