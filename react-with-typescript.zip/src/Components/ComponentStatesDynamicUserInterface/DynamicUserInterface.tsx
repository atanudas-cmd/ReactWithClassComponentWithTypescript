import React, { Component } from 'react'

interface IState {
    count:number,
}

export default class DynamicUserInterface extends Component<any,IState> {
    constructor(props:any) {
      super(props)
    
      this.state = {
         count : 0,
      };
    };

    incrementCount=()=>{
        this.setState((prevState)=>({
            count:prevState.count + 1,
        }));
    };

    decrementCount=()=>{
        this.setState((prevState)=>({
            count:prevState.count - 1,
        }));
    };
    
  render() {
    return (
      <div>
        <h2>Counter : {this.state.count}</h2>
        <button onClick={this.incrementCount}>Increment</button>
        <button onClick={this.decrementCount}>Decrement</button>
      </div>
    )
  }
}


/*
In React class components with TypeScript, you can use component state to create dynamic user interfaces that can update 
and re-render based on changes in data or user interactions. Component state allows you to manage and store data within
the component itself, and when the state changes, React automatically re-renders the component to reflect the updated state.
*/