/*
To create a stateful list in a React class component, you need to use the 
component's state to manage the list data and handle updates. 
*/
import React, { ChangeEvent, Component } from 'react';
interface Istate {
    items: string[],
    newItem: string
}
export default class StatefullList extends Component<any, Istate> {
    constructor(props: any) {
        super(props)

        this.state = {
            items: ['Item 1', 'Item 2', 'Item 3'],
            newItem: ''
        };
    }

    addItem = () => {
        const { items, newItem } = this.state;
        if (newItem) {
            this.setState({
                items: [...items, newItem],
                newItem: ''
            });
        }
    }

    handleChange = (event: ChangeEvent<HTMLInputElement>) => {
        this.setState({ newItem: event.target.value });
    }

    render() {
        const { items, newItem } = this.state;
        return (
            <div>
                <h1>List of Items</h1>
                <ul>
                    {items.map((item, index) => (
                        <li key={index}>{item}</li>
                    ))}
                </ul>
                <input type="text" value={newItem} onChange={this.handleChange} />
                <button onClick={this.addItem}>Add Item</button>
            </div>
        )
    }
}




/*
In this example, the `ListComponent` class component has a state object that includes an `items` array and a `newItem` string. The `items` 
array holds the list of items, and the `newItem` string stores the value of the input field for adding new items.

The `addItem` method is called when the "Add Item" button is clicked. It checks if the `newItem` value is not empty and updates 
the state by adding the `newItem` to the `items` array and resetting the `newItem` value.

The `handleChange` method is called when the value of the input field changes. It updates the `newItem` value in the state based 
on the user input.

Within the `render` method, the `items` array is mapped using the `map()` method to generate the list of `<li>` elements. 
Each item in the array is rendered as a separate list item.

The input field allows users to enter a new item, and the "Add Item" button triggers the `addItem` method to add the new item to the list.

By managing the list data in the component's state, you can dynamically update the list based on user input or other events.
 This allows you to create interactive and stateful lists in React class components.
*/