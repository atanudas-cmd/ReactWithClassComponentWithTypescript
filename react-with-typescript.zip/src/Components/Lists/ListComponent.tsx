import React, { Component } from 'react'
interface IState {
    items: string,
    index: number,
    item: string
}
export default class ListComponent extends Component<any,IState> {
    render() {
        const items: string[] = ['Item 1 ', 'Item 2 ', 'Item 3 '];
        return (
            <div>
                <h1>List of Items</h1>
                <ul>
                    {items.map((item, index) => (
                        <li key={index}>{item}</li>
                    ))}
                </ul>
            </div>
        )
    }
}
